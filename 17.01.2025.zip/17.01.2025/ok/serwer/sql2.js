
const express = require("express")
const cors = require("cors")
const app = express()
app.use(cors())

var mysql = require("mysql");

var con =  mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'',
    database:'library',
})

con.connect((err)=>{
    if(!err){
        console.log('polczono z baza');
    }else{
        console.log('nie polczono z baza');
    }
})

app.get("/books", (req,res)=>{
    const sql = `SELECT * FROM books`
    con.query(sql, (err,wynik,info_wynik)=>{
        res.send(wynik)
        console.log(info_wynik);
    })

})


app.get("/add-book/:title/:autor", (req,res)=>{
    let title = req.params.title
    let autor = req.params.autor

    const sql = `INSERT INTO books (title, author) VALUES ('${title}','${autor}')`

    con.query(sql, (err,wynik,info_wynik)=>{
        res.send("Dodano");
    })
})

app.get("/aktualizacja/:tytul1/:autor1/:tytul2/:autor2", (req,res)=>{
    let tytul1 = req.params.tytul1
    let autor1 = req.params.autor1
    let tytul2 = req.params.tytul2
    let autor2 = req.params.autor2
    

    const sql = `UPDATE books SET title = '${tytul2}', author = '${autor2}' WHERE author = '${autor1}' AND  title = '${tytul1}'`

    con.query(sql, (err,wynik,info_wynik)=>{
        res.send("Zmieniono");
    })
})

app.get("/delete-books/:title/:autor", (req,res)=>{
    let title = req.params.title
    let autor = req.params.autor

    const sql = `DELETE FROM books WHERE title = '${title}' AND author = '${autor}' `

    con.query(sql, (err,wynik,info_wynik)=>{
        res.send("Usunieto");
    })
})



app.listen(3000, ()=>{
    console.log('dziala');
})
