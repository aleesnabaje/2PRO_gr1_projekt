let btn = document.querySelector("button")
let divinio = document.getElementById("divek")

async function dodawanie() {

    let ksiazka = document.getElementById("ksiazka").value
    let autor = document.getElementById("autor").value
    fetch(`http://localhost:3000/add-book/${ksiazka}/${autor}`)

}

btn.addEventListener("click", ()=>{
    alert("Dodano rekord.")
})

async function lista() {
    let tab = document.querySelector("table");
    tab.innerHTML = ""

    let data = await fetch("http://localhost:3000/books")
    data = await data.json()

    let tr1 = document.createElement("tr")

    let th1 = document.createElement("th")
    th1.innerHTML = "ID"

    let th2 = document.createElement("th")
    th2.innerHTML = "Tytuł"

    let th3 = document.createElement("th")
    th3.innerHTML = "Autor"

    let th4 = document.createElement("th")
    th4.innerHTML = "Ustawienia"

    tr1.appendChild(th1)
    tr1.appendChild(th2)
    tr1.appendChild(th3)
    tr1.appendChild(th4)

    tab.appendChild(tr1)

    for (let i = 0; i < data.length; i++) {

        let usun = document.createElement("button")
        let aktu = document.createElement("button")

        usun.innerHTML = "Usuń"
        aktu.innerHTML = "Aktualizuj książkę"

        const tr = document.createElement("tr")

        const ustaw = document.createElement("td")

        const tdid = document.createElement("td")
        tdid.innerHTML = data[i].id

        const tdtytul = document.createElement("td")
        tdtytul.innerHTML = data[i].title

        const tdautor = document.createElement("td")
        tdautor.innerHTML = data[i].author

        ustaw.appendChild(usun);
        ustaw.appendChild(aktu);

        tr.appendChild(tdid)
        tr.appendChild(tdtytul)
        tr.appendChild(tdautor)
        tr.appendChild(ustaw)

        tab.appendChild(tr)

        usun.addEventListener("click", async function () {
            let title = data[i].title;
            let author = data[i].author;
            await fetch(`http://localhost:3000/delete-books/${title}/${author}`)
            tab.removeChild(tr)
        })

        aktu.addEventListener("click", async function () {
            let tytul1 = data[i].title;
            let autor1 = data[i].author;
            let nazwa2 = prompt("Podaj nowy tytuł")
            let autor2  = prompt("Podaj nowego autora")
            await fetch(`http://localhost:3000/aktualizacja/${tytul1}/${autor1}/${nazwa2}/${autor2}`)
            lista()
        })
    }
    divinio.appendChild(tab)
}

